var pos = 0, test, test_status, question, choice, choices, choiceA, choiceB, choiceC, choiceD, correct=0, name = 0; 
//setting variables

//Set array to hold answers
var quizAnswers = [];

var questions=[
    {
	    question: "What year was the Tulla Ceili Band founded?",//question
		correctAnswer: "1946",//right answer to question
		
		//list of multiple choice answers
		answer0: "1946",
		answer1: "1956",
		answer2: "1966",
		answer3: "1976"
	},
    {
	    question: "Name the Clare town where the Willie Clancy Summer school is held in July of each year?",//question
		correctAnswer: "Milltown Malbay",//right answer to question
		
		//list of multiple choice answers
		answer0: "Kilrush",
		answer1: "Milltown Malbay",
		answer2: "Ennis",
		answer3: "Tulla"
	},
    {
	    question: "What month does the Feakle Music festival take place each year?",//question
		correctAnswer: "August",//right answer to question
		
		//list of multiple choice answers
		answer0: "June",
		answer1: "July",
		answer2: "August",
		answer3: "September"
	},
    {
	    question: "Name the singer who wrote the song The Wagon Wheel?",//question
		correctAnswer: "Bob Dylan",//right answer to question
		
		//list of multiple choice answers
		answer0: "Bob Dylan",
		answer1: "Johnny Cash",
		answer2: "Gerry Guthrie",
		answer3: "Brendan Shine"
	},
	{
		question: "What is the name of the singer who sings the song Thinking out Loud?",//question
		correctAnswer: "Ed Sheeran",//right answer to question
		
		//list of multiple choice answers
		answer0: "Ed Sheeran",
		answer1: "Lee Matthews",
		answer2: "Isla Grant",
		answer3: "Lisa Mc Hugh"
	},
	{
		question: "Name the song that the band The Script sing?",//question
		correctAnswer: "Hall of Fame",//right answer to question
		
		//list of multiple choice answers
		answer0: "Hall of Fame",
		answer1: "All of Me",
		answer2: "Counting Stars",
		answer3: "Impossible"
	},
	{
		question: "What nationality is the singer Mike Denver?",//question
		correctAnswer: "Irish",//right answer to question
		
		//list of multiple choice answers
		answer0: "Irish",
		answer1: "English",
		answer2: "American",
		answer3: "Scottish"
	},
	{
		question: "What nationality is the singer Lisa Mc Hugh?",//question
		correctAnswer: "Scottish",//right answer to question
		
		//list of multiple choice answers
		answer0: "Irish",
		answer1: "Scottish",
		answer2: "English",
		answer3: "Welsh"
	},
	{
		question: "Who sings the song High Hopes?",//question
		correctAnswer: "Kodaline",//right answer to question
		
		//list of multiple choice answers
		answer0: "Kodaline",
		answer1: "One Republic",
		answer2: "The Script",
		answer3: "Owl City"
	},
	{
		question: "Name 2 band members from the band The Dubliners?",//question
		correctAnswer: "Ronnie Drew and Luke Kelly",//right answer to question
		
		//list of multiple choice answers
		answer0: "Ronnie Drew and Luke Kelly",
		answer1: "Johnny Cash and June Carter",
		answer2: "Brendan and Emily Shine",
		answer3: "Lisa Mc Hugh and Nathan Carter"
	},
	{
		question: "Who represented Ireland in the Eurovision song contest in 1970 and sang the song All Kinds of Everything?",//question
		correctAnswer: "Rosemary Scallon",//right answer to question
		
		//list of multiple choice answers
		answer0: "Dolores Keane",
		answer1: "Johnny Logan",
		answer2: "Rosemary Scallon",
		answer3: "Mary Black"
	},
	{
		question: "What year did Ireland last win the Eurovision Song Contest?",//question
		correctAnswer: "1996",//right answer to question
		
		//list of multiple choice answers
		answer0: "1966",
		answer1: "1976",
		answer2: "1986",
		answer3: "1996"
	},
	{
		question: "What year was Dustin the turkey voted out of the Eurovision Song Contest after representing Ireland in the semi-final?",//question
		correctAnswer: "2008",//right answer to question
		
		//list of multiple choice answers
		answer0: "2008",
		answer1: "2009",
		answer2: "2010",
		answer3: "2011"
	},
	{
		question: "Name the singers who sang the song Rock and Roll Kids in the 1994 Eurovision Song Contest?",//question
		correctAnswer: "Charlie Mc Gettigan and Paul Harrington",//right answer to question
		
		//list of multiple choice answers
		answer0: "Mary Black and Dolores Keane",
		answer1: "Charlie Mc Gettigan and Paul Harrington",
		answer2: "The High Kings",
		answer3: "The Dubliners"
	},
	{
		question: "Which singer sings the song Fuzzy Blue Lights?",//question
		correctAnswer: "Owl City",//right answer to question
		
		//list of multiple choice answers
		answer0: "Michael English",
		answer1: "Owl City",
		answer2: "Nathan Carter",
		answer3: "Johnny Brady"
	},
	{
		question: "What nationality is the singer Robert Mizzell?",//question
		correctAnswer: "American",//right answer to question
		
		//list of multiple choice answers
		answer0: "Irish",
		answer1: "English",
		answer2: "American",
		answer3: "Scottish"
	},
	{
		question: "Name the singer who used to sing the song Paddy Mc Gintys Goat?",//question
		correctAnswer: "Val Doonican",//right answer to question
		
		//list of multiple choice answers
		answer0: "Val Doonican",
		answer1: "Johnny Cash",
		answer2: "Marty Robbins",
		answer3: "Luke Kelly"
	},
	{
		question: "Name 2 other songs that Val Doonican used to sing?",//question
		correctAnswer: "Walk Tall and The day Delaneys donkey won the half mile race",//right answer to question
		
		//list of multiple choice answers
		answer0: "The Ring of Fire and I walk the line",
		answer1: "Walk Tall and The day Delaneys donkey won the half mile race",
		answer2: "Finnegans Wake and Dirty old Town",
		answer3: "Rocky road to Dublin and Whiskey in the Jar"
	},
	{
		question: "What is the name of the singer who used to sing The ring of Fire?",//question
		correctAnswer: "Johnny Cash",//right answer to question
		
		//list of multiple choice answers
		answer0: "Luke Kelly",
		answer1: "Ronnie Drew",
		answer2: "Barney Mc Kenna",
		answer3: "Johnny Cash"
	},
	{
		question: "Who used to sing the song I walk the line?",//question
		correctAnswer: "Johnny Cash",//right answer to question
		
		//list of multiple choice answers
		answer0: "Johnny Cash",
		answer1: "Val Doonican",
		answer2: "Barney Mc Kenna",
		answer3: "David Bowie"
	},
];

/*
var questions=[
    ['What is 99 divided by 3?', 30, 33, 36, "B"],
    ['What is 34 multiplied by 2?', 36, 68, 66, "B"],
    ['What is 25% of 200?', 100, 80, 50, "C"],
    ['What is one third of 900?', 100, 300, 150, "B"],
    ['What is 5 multiplied by 25?', 100, 150, 125, "C"],
    ['Divide 4/8 by 0.5.', 0.25, 2.25, 0.5, "A"],
    ['Multiply 0.75 by 100. ', 75, 25, 50, "A"],
    ['What is 40% of 200?', 40, 80, 60, "B"],
    ['Take 39 away from 92.', 43, 53, 63, "B"],
    ['What is 66x2?', 122, 132, 120, "B"]
]; */

//function which takes an array and shuffles its contents
//used to get different order of multiple choice answers every time quiz is taken
function shuffleArray(array) 
{
	for (var i = array.length - 1; i > 0; i--) 
	{
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
	}
	return array;
}

//Above I have set my questions, 3 multi-choice answers and the answers in an multi-dimensional array, zero indexed
function _(x)
{ 
    return document.getElementById(x);
} 
//Setting underscore equal to document.getElementById
		
function percent()
{
    var perc = Math.round((correct/questions.length)*100);
    return perc;//gets percentage and returns to form
}

function renderQuestion()
{ 
    test = _("test"); 
    if(pos >= questions.length)//If position is greater or equal to the length of question, ie 20
    { 
        test.innerHTML = "<h2>You got "+correct+" of "+questions.length+" questions correct (" +percent() + "%)</h2>";//Print # correct out of 20
        _("test_status").innerHTML += "  Thank you for completing the quiz";//Print "thank you .... "
        pos = 0;
        correct = 0; 
        return false; 
    }

    _("test_status").innerHTML = "Question "+(pos+1)+" of "+questions.length;
    //Print questions and increment by one each iteration

    var bar=document.getElementById("progressBar");//Progress bar value
    bar.value = (pos+1);//Progress bar increments as we go through questions, starts at 1

    //console.log("Pos value is " + pos);//write this to console

    //push all potential answers to the quizAnswers array
    quizAnswers[0] = questions[pos].answer0;
    quizAnswers[1] = questions[pos].answer1;
    quizAnswers[2] = questions[pos].answer2;
    quizAnswers[3] = questions[pos].answer3;
    
    console.log("Unshuffled answers" + quizAnswers);
    
    //Shuffle the answers
    var shuffledAnswers = shuffleArray(quizAnswers);
    
    console.log("Shuffled answers" + shuffledAnswers);
    
    question = questions[pos].question;//question is in position 0 in the array(zero indexed)
    choiceA = shuffledAnswers[0]; //choice A is in position 1 in the array
    choiceB = shuffledAnswers[1]; //choice B is in position 2 in the array
    choiceC = shuffledAnswers[2]; //choice C is in position 3 in the array
    choiceD = shuffledAnswers[3]; //choice D is in position 4 in the array
    
    test.innerHTML = "<h3>"+question+"</h3>"; //questions are written in h3 size
    test.innerHTML += "<input type='radio' name='choices' value='"+choiceA+"' checked> "+choiceA+"<br>"; //Radio button
    test.innerHTML += "<input type='radio' name='choices' value='"+choiceB+"'> "+choiceB+"<br>"; //Radio button
    test.innerHTML += "<input type='radio' name='choices' value='"+choiceC+"'> "+choiceC+"<br>"; //Radio button
    test.innerHTML += "<input type='radio' name='choices' value='"+choiceD+"'> "+choiceD+"<br><br>"; //Radio button
    test.innerHTML += "<button onclick='checkAnswer()'>Submit Answer</button>";//on clicking submit button, it checks your answers
}
		
		
function checkAnswer()
{ 
    choices = document.getElementsByName("choices"); //Creates an array
    for(var i=0; i<choices.length; i++)//variable i=0, when i is less than the length of the choices, increment it by one
    { 
        if(choices[i].checked) //if a choice is checked
        { 
            choice = choices[i].value; //Take the value of that choice and put it into choice
        }
    } 
    console.log("Chosen answer is " + choice);
    if(choice == questions[pos].correctAnswer)//If the value of choices is equal to the answer
    { 
        alert('Correct!');//Alert correct
        correct++;//Increment your correct answers by one
    }
    else//or else
    {
        alert('Sorry wrong answer. The correct answer is ' + questions[pos].correctAnswer);
    } 
    pos++; //Increment position by one ie go on to the next question
    
    renderQuestion(); //go to render question again
}

//Call the question with an event handler
window.addEventListener("load", renderQuestion, false);